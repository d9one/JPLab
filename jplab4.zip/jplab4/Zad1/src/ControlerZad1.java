import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;

public class ControlerZad1 extends JPanel implements ActionListener {
    private final JButton add;
    private final JButton delete;
    private final JButton edit;
    private final JList<Integer> list;
    private final JTextField textField;
    final WykresKolo displayPanelInstance = new WykresKolo();
    Set<Integer> liczby = new HashSet<>();


    public ControlerZad1() {
        list = new JList<>(new DefaultListModel<>());
        textField = new JTextField();
        add = new JButton("Dodaj");
        delete = new JButton("Usuń");
        edit = new JButton("Edytuj");

        JScrollPane scrollPane = new JScrollPane(list);

        JPanel control = new JPanel();
        control.setLayout(new GridLayout(2,1));
        control.add(scrollPane);
        control.add(textField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(add);
        buttonPanel.add(delete);
        buttonPanel.add(edit);

        JPanel controlerPanel = new JPanel();
        controlerPanel.setLayout(new BorderLayout());
        controlerPanel.add(control, BorderLayout.NORTH);
        controlerPanel.add(buttonPanel, BorderLayout.CENTER);

        JPanel display = new JPanel();
        display.add(displayPanelInstance);

        add.setPreferredSize(new Dimension(100, 50));
        delete.setPreferredSize(new Dimension(100, 50));
        edit.setPreferredSize(new Dimension(100, 50));
        textField.setPreferredSize(new Dimension(300, 50));

        Font font = new Font("SansSerif", Font.BOLD, 30);
        textField.setHorizontalAlignment(JTextField.CENTER);
        textField.setFont(font);

        setLayout(new BorderLayout());
        add(controlerPanel, BorderLayout.EAST);
        add(display, BorderLayout.WEST);


        scrollPane.setViewportView(list);
        list.setLayoutOrientation(JList.VERTICAL);

        add.addActionListener(this);
        delete.addActionListener(this);
        edit.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == add) {
            DefaultListModel<Integer> model = (DefaultListModel<Integer>) list.getModel();
            try {
                Integer value = Integer.parseInt(textField.getText());
                if(model.contains(value)){
                    JOptionPane.showMessageDialog(this, "Podana liczba juz się znajduje na liście: " + value, "Błąd", JOptionPane.ERROR_MESSAGE);
                }
                else if (value<0) {
                    JOptionPane.showMessageDialog(this, "Podana liczba jjest ujemna: " + value, "Błąd", JOptionPane.ERROR_MESSAGE);
                }
                else{
                    model.addElement(value);
                    textField.setText("");
                    liczby.add(value);
                    System.out.println(liczby);
                    displayPanelInstance.setNumbers(liczby);
                    repaint();
                }
            } catch (NumberFormatException exception) {
                JOptionPane.showMessageDialog(this, "Wprowadź poprawną liczbę", "Błąd", JOptionPane.ERROR_MESSAGE);
            }
        }
        if (source == delete) {
            int selectedIndex = list.getSelectedIndex();
            DefaultListModel<Integer> model = (DefaultListModel<Integer>) list.getModel();
            if (selectedIndex != -1) {
                int help = model.getElementAt(selectedIndex);
                model.removeElementAt(selectedIndex);
                liczby.remove(help);
                System.out.println(liczby);
                displayPanelInstance.setNumbers(liczby);
                repaint();
            } else {
                JOptionPane.showMessageDialog(this, "Wybierz element do usunięcia", "BŁąd", JOptionPane.ERROR_MESSAGE);
            }

        }
        if (source == edit) {
            int selectedIndex = list.getSelectedIndex();
            DefaultListModel<Integer> model = (DefaultListModel<Integer>) list.getModel();
            if (selectedIndex != -1) {
                try {
                    Integer value = Integer.parseInt(textField.getText());
                    if(model.contains(value)){
                        JOptionPane.showMessageDialog(this, "Podana liczba juz się znajduje na liście: " + value, "Błąd", JOptionPane.ERROR_MESSAGE);
                    }
                    else{
                        int help = model.getElementAt(selectedIndex);
                        model.setElementAt(value, selectedIndex);
                        textField.setText("");
                        liczby.remove(help);
                        liczby.add(value);
                        System.out.println();
                        displayPanelInstance.setNumbers(liczby);
                        repaint();
                    }

                } catch (NumberFormatException exception) {
                    JOptionPane.showMessageDialog(this, "Wprowadź poprawną liczbę całkowitą.", "Błąd", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Wybierz element do edycji", "BŁąd", JOptionPane.ERROR_MESSAGE);
            }
        }


    }

}