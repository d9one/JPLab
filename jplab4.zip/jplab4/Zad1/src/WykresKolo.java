import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.HashSet;
import java.util.Set;

public class WykresKolo extends JPanel {
    Set<Integer> numbers = new HashSet<>();

    public WykresKolo() {
        setPreferredSize(new Dimension(400, 400));
    }

    public void setNumbers(Set<Integer> numbers) {
        if (numbers != null) {
            this.numbers = numbers;
            System.out.println(numbers);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        System.out.println("paintComponent");

        Graphics2D g2d = (Graphics2D) g;

        int diameter = Math.min(getWidth(), getHeight());
        int x = (getWidth() - diameter) / 2;
        int y = (getHeight() - diameter) / 2;

        Ellipse2D.Double circle = new Ellipse2D.Double(x, y, diameter, diameter);

        g2d.setColor(Color.WHITE);
        g2d.fill(circle);


        double suma=0;
        for (Integer liczba : numbers) {
            suma += liczba;
        }
        double obecnaWartosc = 0.0D;
        int katStartowy = 0;
        for (Integer liczba : numbers) {
            katStartowy = (int) (obecnaWartosc * 360.0 / suma);
            int kat = (int) (liczba * 360.0 / suma);
            g2d.setColor(getColorNumber(liczba));
            g2d.fillArc(x, y, diameter, diameter, katStartowy, kat);
            obecnaWartosc += liczba;
        }
    }

    private static Color getColorNumber(int number) {
        number = (number * 137) + 2000;

        int R = (number & 0xFF);
        int G = ((number >> 8) & 0xFF);
        int B = ((number >> 16) & 0xFF);

        return new Color(R, G, B);
    }
}
