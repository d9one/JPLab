import javax.swing.*;
import java.awt.*;

public class Zad2 extends JFrame {
    public Zad2() {
        super("Zadanie2");

        controlerZad2 controlerPanel = new controlerZad2();
        setContentPane(controlerPanel);
        setPreferredSize(new Dimension(875, 500));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
        setResizable(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Zad2::new);
    }
}
