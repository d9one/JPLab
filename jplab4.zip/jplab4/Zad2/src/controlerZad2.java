import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class controlerZad2 extends JPanel implements ActionListener {
    private JPanel controlPanel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JTextField textField8;
    private JTextField textField9;
    private JTextField textField10;
    private JCheckBox checkBox1;
    private JCheckBox checkBox2;
    private JCheckBox checkBox3;
    private JCheckBox checkBox4;
    private JCheckBox checkBox5;
    private JCheckBox checkBox6;
    private JCheckBox checkBox7;
    private JCheckBox checkBox8;
    private JCheckBox checkBox9;
    private JCheckBox checkBox10;

    private final ArrayList<Integer> numberList = new ArrayList<>();
    private final ArrayList<JCheckBox> checkBoxes = new ArrayList<>();
    private  final ArrayList<JTextField> textFields = new ArrayList<>();
    private static WykresSlupek wykresSlupek = new WykresSlupek();

    public controlerZad2(){
        checkBoxes.add(checkBox1);
        checkBoxes.add(checkBox2);
        checkBoxes.add(checkBox3);
        checkBoxes.add(checkBox4);
        checkBoxes.add(checkBox5);
        checkBoxes.add(checkBox6);
        checkBoxes.add(checkBox7);
        checkBoxes.add(checkBox8);
        checkBoxes.add(checkBox9);
        checkBoxes.add(checkBox10);

        textFields.add(textField1);
        textFields.add(textField2);
        textFields.add(textField3);
        textFields.add(textField4);
        textFields.add(textField5);
        textFields.add(textField6);
        textFields.add(textField7);
        textFields.add(textField8);
        textFields.add(textField9);
        textFields.add(textField10);
        for (JCheckBox checkBox: checkBoxes){
            checkBox.addActionListener(this);
        }

        controlPanel.setPreferredSize(new Dimension(200, 500));

        setLayout(new BorderLayout());
        add(controlPanel, BorderLayout.EAST);
        add(wykresSlupek, BorderLayout.WEST);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        int index = checkBoxes.indexOf(e.getSource());
        JCheckBox source = (JCheckBox) e.getSource();

        if (source.isSelected()) {
            Timer timer = new Timer(100, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    numberList.clear();
                    for (int i = 0; i < 10; i++) {
                        if (checkBoxes.get(i).isSelected()) {
                            try{
                                int number = Integer.parseInt(textFields.get(i).getText());
                                if(number<0){
                                    System.out.println("Błąd");
                                }
                                else{
                                    System.out.println(number);
                                    numberList.add(number);
                                }
                            }
                            catch (Exception ignored){
                            }
                        }
                    }
                    wykresSlupek.setNumberList(numberList);
                    repaint();

                }
            });
            timer.start();
        }

        if (!source.isSelected()) {
            try {
                numberList.remove(index);
                wykresSlupek.setNumberList(numberList);
                repaint();
            } catch (Exception ignored) {
            }
        }

        for (Integer x : numberList) {
            System.out.println(x);
        }
    }

    private Integer textFieldNumber(JTextField jTextField){
        Integer number = null;
        try {
            number = Integer.parseInt(jTextField.getText());
        }
        catch (NumberFormatException ignored){
        }
        return number;
    }
}
