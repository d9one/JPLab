import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;

public class WykresSlupek extends JPanel {
    private ArrayList<Integer> numberList = new ArrayList<>();
    private ArrayList<Color> colorList = new ArrayList<>();
    private int barGap = 5;

    public WykresSlupek() {
        setPreferredSize(new Dimension(600, 300));
        colorList.add(Color.CYAN);
        colorList.add(Color.ORANGE);
        colorList.add(Color.GREEN);
        colorList.add(Color.MAGENTA);
        colorList.add(Color.RED);
        colorList.add(Color.BLUE);
        colorList.add(Color.YELLOW);
        colorList.add(Color.BLACK);
        colorList.add(Color.DARK_GRAY);
        colorList.add(Color.PINK);
    }

    public void setNumberList(ArrayList<Integer> numberList) {
        this.numberList = numberList;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Rectangle area = getBounds();
        int numberOfBars = numberList.size();
        if (numberOfBars == 0) {
            return;
        }

        int barWidth = (area.width - (numberOfBars - 1) * barGap) / numberOfBars;
        int max = numberList.stream().filter(Objects::nonNull).max(Integer::compare).orElse(1);

        for (int i = 0; i < numberOfBars; i++) {
            int liczba = numberList.get(i) != null ? numberList.get(i) : 0;
            g.setColor(colorList.get(i));

            double height = ((double) liczba / (double) max) * area.height;
            int x = i * (barWidth + barGap);
            int y = (int) (area.height - height);

            g.fillRect(x, y, barWidth, (int) height);
        }
    }
}
