public enum Imiona {
    Dawid,
    Kuba,
    Piotr,
    Maciek;

}
