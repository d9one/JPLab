public class imieCounter{
    private final String name;
     private int count;
     private  final String plik;

    public int getCount() {
        return count;
    }

    public imieCounter(String name, String plik){
        this.name = name;
        this.plik = plik;
        count = 1;
    }

    public String getName() {
        return name;
    }

    public String getPlik() {
        return plik;
    }

    public void increase()
    {
        count++;
    }

}