import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        if(args.length!=3){
            throw new IndexOutOfBoundsException("Podaj 3 pliki");
        }
        List<List<imieCounter>> litery = new ArrayList<>();
        for (int i = 0; i < Litery.values().length; i++) {
            litery.add(new ArrayList<>());
        }
        for (int i = 0; i < 3; i++) {
            File file = new File(args[i]);
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String imieString = reader.nextLine();
                if (imieString == null || imieString.isEmpty()) continue;
                Imiona imie = null;
                for (Imiona enumValue : Imiona.values()) {
                    if (enumValue.name().equals(imieString)) {
                        imie = enumValue;
                        break;
                    }
                }
                if (imie == null) {
                    System.out.println("Nieprawidłowe imię: " + imieString);
                    continue;
                }
                List<imieCounter> listaImion = litery.get(Litery.valueOf(imieString.substring(0, 1)).ordinal());
                imieCounter imieCounter = null;
                for (imieCounter x : listaImion) {
                    if(x.getName().equals(imieString) && x.getPlik().equals(args[i])){
                        x.increase();
                        imieCounter = x;
                        break;
                    }
                }
                if (imieCounter == null) {
                    imieCounter noweImie = new imieCounter(imieString, args[i]);
                    listaImion.add(noweImie);
                }
            }
        }

        for (Litery litera : Litery.values()) {
            System.out.println(litera.toString());
            for (imieCounter imieCounter : litery.get(litera.ordinal())) {
                System.out.println(imieCounter.getName() + ": " + imieCounter.getCount() + ": " + imieCounter.getPlik());
            }
        }
    }
}
