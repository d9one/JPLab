import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

public class Klient {
    public static void main(String[] args) throws IOException, zlyParametrException, brakArtykuluWKoszykuException {
        Magazyn magazyn = new Magazyn();
        Koszyk koszyk = new Koszyk();
        EasyReader easyReader = new EasyReader();
        int menu = 0;
        while(menu!=-1){
            System.out.println("Menu: ");
            System.out.println("Wyswietl artykuly: 1");
            System.out.println("Dodaj do koszyka: 2");
            System.out.println("Usun z koszyka: 3");
            System.out.println("Wycen koszyk: 4");
            System.out.println("Zrealizuj zamowienie: 5");
            System.out.println("Zakoncz dzialanie programu : -1");
            menu = easyReader.readInt();
            switch (menu){
                case 1:
                    for (Artykul artykul:magazyn.getArtykuly()) {
                        System.out.println(artykul);
                    }
                    break;
                case 2:
                    System.out.println("Podaj nazwe: ");
                    String nazwa = easyReader.readLine();
                    Artykul artykul = new Artykul();
                    try{
                            artykul = magazyn.znajdzArtykul(nazwa);
                            System.out.println("Dodano artykul do koszyka");
                    }
                    catch (zlyParametrException e){
                        System.out.println("Nie udalo sie znalezc artykulu");
                    }
                    if(artykul.getNazwa()!=null){
                        koszyk.dodajDoKoszyka(artykul);
                    }
                    break;
                case 3:
                    System.out.println("Nazwa artykulu:");
                    String nazwa1 = easyReader.readLine();
                    Optional<Artykul> artykul1 = magazyn.znajdzArtykul(koszyk.listaArtykulow(), nazwa1);
                    if (artykul1.isPresent()) {
                        System.out.println("Podaj ilosc do usuniecia. Dostepna ilosc to " + koszyk.iloscArtykulu(artykul1.get()));
                        Integer ilosc = easyReader.readInt();
                        try {
                            koszyk.usunZKoszyka(artykul1.get(), ilosc);
                            System.out.println("Usunieto artykul");
                        } catch (brakArtykuluWKoszykuException e) {
                            System.out.println(e.getMessage());
                        }
                    } else {
                        System.out.println("Nie znaleziono artykulu");
                    }
                    break;
                case 4:
                    System.out.println("Zawartosc koszyka to: " + koszyk.getArtykulyKoszyk());
                    System.out.println("Cena koszyka to: " + koszyk.wycenaZamownienia(koszyk.getArtykulyKoszyk()));
                    break;
                case 5:
                    for (Artykul artykul2 : koszyk.listaArtykulow()) {
                        magazyn.pobierzArtykul(artykul2);
                    }
                    magazyn.zapisDoPliku();
                    System.out.println("Zreazlizowano zamowienie");
                    break;
                case -1:
                    System.exit(0);
                default:
                    System.out.println("Podaj liczbe: 1-3, -1");
            }
        }
    }
}
