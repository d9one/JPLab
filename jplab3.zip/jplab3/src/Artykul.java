public class Artykul {
    private String kod;
    private String nazwa;
    private float cena;

    public String getKod() {
        return kod;
    }

    public String getNazwa() {
        return nazwa;
    }

    public float getCena() {
        return cena;
    }

    public Artykul(String kod, String nazwa, float cena){
        this.kod = kod;
        this.nazwa = nazwa;
        this.cena = cena;
    }

    public Artykul() {
    }

    @Override
    public String toString() {
        return "kod='" + kod + '\'' +
                ", nazwa='" + nazwa + '\'' +
                ", cena=" + cena;
    }
}
