public class brakArtykuluWKoszykuException extends Exception{
    public brakArtykuluWKoszykuException(){
        super("Nie masz takiego artykulu w koszyku");
    }
}
