import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Magazyn {
    private  List<Artykul> artykuly = new ArrayList<>();

    public Magazyn() throws FileNotFoundException {
        String currentDir = System.getProperty("user.dir");
        File magazynFile = new File(currentDir + "\\src\\magazyn.txt");
        Scanner scanner = new Scanner(magazynFile);
        while(scanner.hasNextLine()){
            String[] parametry = scanner.nextLine().split(" ");
            artykuly.add(new Artykul(parametry[0], parametry[1], Float.parseFloat(parametry[2])));
        }
    }

    public List<Artykul> getArtykuly() {
        return this.artykuly;
    }
    public void pobierzArtykul(Artykul artykul)throws zlyParametrException {
        this.artykuly.remove(artykul);
    }
    public void dodajArtykul(Artykul artykul)throws zlyParametrException {
        this.artykuly.add(artykul);
    }
    public Artykul znajdzArtykul(String nazwa)throws zlyParametrException {
        Artykul znalezionyArtykul = null;
        for (Artykul artykul: artykuly) {
            if(artykul.getNazwa().equals(nazwa)){
                znalezionyArtykul = artykul;
                break;
            }
        }
        if(znalezionyArtykul==null){
            throw new zlyParametrException();
        }
        return znalezionyArtykul;
    }
    public Optional<Artykul> znajdzArtykul(List<Artykul> artykuly, String nazwa) {
        String finalNazwa = nazwa.replace("*", ".*").replace("?", ".{1}");
        return artykuly.stream().filter(a -> a.getNazwa().matches(finalNazwa)).findFirst();
    }
    public void zapisDoPliku() throws IOException {
        String currentDir = System.getProperty("user.dir");
        FileWriter fileWriter = new FileWriter(currentDir + "\\src\\magazyn.txt");
        PrintWriter printWriter = new PrintWriter(fileWriter);
        for (Artykul artykul: artykuly) {
            printWriter.println(artykul.getKod() + " " + artykul.getNazwa() + " " + artykul.getCena());
        }
        printWriter.close();
    }
}
