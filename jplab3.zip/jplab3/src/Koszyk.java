import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Koszyk {
    Map<Artykul, Integer> artykulyKoszyk = new HashMap<>();

    public Map<Artykul, Integer> getArtykulyKoszyk() {
        return artykulyKoszyk;
    }

    public float wycenaZamownienia(Map<Artykul, Integer> artykulyKoszyk){
        return (float) artykulyKoszyk.entrySet().stream()
                .mapToDouble(entry -> entry.getKey().getCena() * entry.getValue())
                .sum();
    }
    public void dodajDoKoszyka(Artykul artykul) throws zlyParametrException {
        this.artykulyKoszyk.put(artykul, this.artykulyKoszyk.containsKey(artykul) ? this.artykulyKoszyk.get(artykul) + 1 : 1);
    }
    public void usunZKoszyka(Artykul artykul, Integer ilosc) throws brakArtykuluWKoszykuException, zlyParametrException {

            if(this.artykulyKoszyk.containsKey(artykul)){
                Integer obecnaIlosc = this.artykulyKoszyk.get(artykul);

                    if (obecnaIlosc > 0 && (obecnaIlosc - ilosc) >= 0) {
                        if((obecnaIlosc - ilosc)>0){
                            this.artykulyKoszyk.put(artykul, obecnaIlosc - ilosc);
                        }
                        else{
                            this.artykulyKoszyk.remove(artykul);
                        }

                    }
                    else {
                        throw new zlyParametrException();
                    }
            }
            else {
                throw new brakArtykuluWKoszykuException();
            }
        }
        public ArrayList<Artykul> listaArtykulow(){
        return new ArrayList<>(artykulyKoszyk.keySet());
        }

        public Integer iloscArtykulu(Artykul artykul) throws brakArtykuluWKoszykuException {
        if(artykulyKoszyk.containsKey(artykul)){
            return this.artykulyKoszyk.get(artykul);
        }
        else{
            throw new brakArtykuluWKoszykuException();
        }
        }
}
