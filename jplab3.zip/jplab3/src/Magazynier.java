import java.io.IOException;
public class Magazynier {
    public static void main(String[] args) throws IOException, zlyParametrException {
        Magazyn magazyn = new Magazyn();
        EasyReader easyReader = new EasyReader();
        int menu = 0;
        while(menu!=-1){
            System.out.println("Menu: ");
            System.out.println("Wyswietl artykuly: 1");
            System.out.println("Dodaj artykul: 2");
            System.out.println("Usun artykul: 3");
            System.out.println("Zakoncz dzialanie programu : -1");
            menu = easyReader.readInt();
            switch (menu){
                case 1:
                    for (Artykul artykul:magazyn.getArtykuly()) {
                        System.out.println(artykul);
                    }
                    break;
                case 2:
                    System.out.println("Podaj nazwe: ");
                    String nazwa = easyReader.readLine();
                    System.out.println("Podaj kod: ");
                    String kod = easyReader.readLine();
                    System.out.println("Podaj cene: ");
                    float cena = (float) easyReader.readDouble();
                    Artykul artykul = new Artykul(kod, nazwa, cena);
                    magazyn.dodajArtykul(artykul);
                    magazyn.zapisDoPliku();
                    System.out.println("Dodano artykul");
                    break;
                case 3:
                    System.out.println("Podaj nazwe: ");
                    String nazwa1 = easyReader.readLine();
                    Artykul artykul1 = new Artykul();
                    try{
                        artykul1 = magazyn.znajdzArtykul(nazwa1);
                        magazyn.pobierzArtykul(artykul1);
                        magazyn.zapisDoPliku();
                        System.out.println("Usunieto artykul");
                    }
                    catch (zlyParametrException e){
                        System.out.println(e.getMessage());
                    }
                    break;
                case -1:
                    System.exit(0);
                default:
                    System.out.println("Podaj liczbe: 1-3, -1");
            }
        }
    }
}
