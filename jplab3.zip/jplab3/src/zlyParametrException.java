import com.sun.security.jgss.GSSUtil;

public class zlyParametrException extends Exception{
    public zlyParametrException(){
        super("Podales zly parametr");
    }
}
