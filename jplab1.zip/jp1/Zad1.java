import java.math.BigInteger;

public class Zad1 {
    public static BigInteger silnia(int x){
        if(x<0){
            throw new IllegalArgumentException("Argumnet nie moze byc mniejszy niz 0");
        }
        if(x==0 || x==1){
            return BigInteger.ONE;
        }
        return BigInteger.valueOf(x).multiply(silnia(x-1));
    }
    public static BigInteger liczba(int x){
        BigInteger liczba= new BigInteger("-1");
        for(int j=3; j<=x; j++){
            BigInteger factorial = silnia(j-2);
            liczba = liczba.add(factorial.subtract(BigInteger.valueOf(j).multiply(factorial.divide(BigInteger.valueOf(j)))));
        }
        return liczba;
    }
    public static void main(String[] args) {

        if(args.length==0){
            System.out.print("Nie podales argumentow");
        }
        else if(args.length==1) {
            if(args[0].matches("\\d+")){
                int n= Integer.parseInt(args[0]);
                if(n<=3) {
                    System.out.print("Argumenty musza byc wieksze od 3");
                }
                else {
                    System.out.print(liczba(n));
                }
            }
            else{
                System.out.print("Argumenty musza byc typu int");
            }
        }
        else{
            System.out.print("Podales wiecej niz 1 argument");
        }




    }
}