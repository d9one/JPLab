public class Zad2 {
    public static int counter=0;
    public static int kolejna(int n){
        if (n == 1) {
            return 1;
        } else if (n % 2 == 0) {
            System.out.print("parzysta, ");
            return n / 2;
        } else {
            System.out.print("nieparzysta, ");
            long liczba = (long) n * 3 + 1;
            if (liczba > Integer.MAX_VALUE) {
                System.out.println("\nPrzekroczyłeś zakres liczby int");
                return 0;
            }
            return (int) liczba;
        }
    }
    public static void print(int n){
        while(counter<1000){
            if(n==1 || n==0){
                break;
            }
            System.out.print(n+", ");
            n=kolejna(n);
            counter++;
            System.out.print(n);
            System.out.println();

        }
    }
    public static void main(String[] args) {
        if(args.length==0){
            System.out.print("Nie podales argumentow");
        }
        else if(args.length==1) {
            if(args[0].matches("\\d+")){
                int n= Integer.parseInt(args[0]);
                print(n);
            }
            else{
                System.out.print("Argumenty musza byc typu int");
            }
        }
        else{
            System.out.print("Podales wiecej niz 1 argument");
        }
    }
}
