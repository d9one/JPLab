public class Variable {
    float number;
    String name;
    public Variable(float number, String name){
        this.number = number;
        try{
            int x = Integer.parseInt(name);
            float value = number * x;
            this.number = value;
            this.name = "";
        }
        catch (NumberFormatException e){
            if(name.contains("-")){
                this.name=name.replace("-", "");
                this.number = number * -1;
            }
            else{
                this.name = name;
            }

        }

    }

    @Override
    public String toString() {
        return  number + name;
    }
}
