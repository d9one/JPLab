import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;


public class ControlPanel extends JPanel implements ActionListener{
    private JButton abcButton;
    private JButton defButton;
    private JButton ghiButton;
    private JButton jklButton;
    private JButton mnoButton;
    private JButton pqrButton;
    private JButton stuvButton;
    private JButton wxyzButton;
    private JButton DMButton;
    private JButton CEButton;
    private JButton CButton;
    private JTextField textfield;
    private JButton equalsButton;
    private JButton divideButton;
    private JButton addButton;
    private JButton substractButton;
    private JPanel controlPanel;
    static String currentText="";
    static String bufforText="";
    static boolean uppercase = false;
    private List<JButton> buttonList = new ArrayList<>();

    public ControlPanel(){
        DMButton.addActionListener(this);
        CEButton.addActionListener(this);
        CButton.addActionListener(this);
        addButton.addActionListener(this);
        substractButton.addActionListener(this);
        divideButton.addActionListener(this);
        equalsButton.addActionListener(this);

        buttonList.add(abcButton);
        buttonList.add(defButton);
        buttonList.add(ghiButton);
        buttonList.add(jklButton);
        buttonList.add(mnoButton);
        buttonList.add(pqrButton);
        buttonList.add(stuvButton);
        buttonList.add(wxyzButton);

        addListener(abcButton, List.of("a", "b", "c"));
        addListener(defButton, List.of("d", "e", "f"));
        addListener(ghiButton, List.of("g", "h", "i"));
        addListener(jklButton, List.of("j", "k", "l"));
        addListener(mnoButton, List.of("m", "n", "o"));
        addListener(pqrButton, List.of("p", "q", "r"));
        addListener(stuvButton, List.of("s", "t", "u", "v"));
        addListener(wxyzButton, List.of("w", "x", "y", "z"));

        setLayout(new FlowLayout());
        add(controlPanel);

    }
    public void addListener(JButton jButton, List<String> value){
        jButton.addActionListener(new ActionListener() {
            long lastClick = -1;
            int count;

            @Override
            public void actionPerformed(ActionEvent e) {
                if(!bufforText.isEmpty() && !value.contains(bufforText.toLowerCase())){
                    currentText += bufforText;
                }

                long now = System.currentTimeMillis();
                if (now - lastClick < 1000) {
                    count++;
                    if (count >= value.size()) {
                        count = 0;
                    }
                } else {
                    count = 0;
                    if(value.contains(bufforText.toLowerCase())){
                        currentText += bufforText;
                    }
                }
                if(uppercase){
                    bufforText = value.get(count).toUpperCase();
                }
                else{
                    bufforText = value.get(count);
                }
                textfield.setText(currentText + bufforText);
                lastClick = System.currentTimeMillis();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String source = e.getActionCommand();

        if(Objects.equals(source, "D/M")){
            uppercase=!uppercase;
            for (JButton jbutton : buttonList) {
                if (uppercase) {
                    jbutton.setText(jbutton.getText().toUpperCase());
                } else {
                    jbutton.setText(jbutton.getText().toLowerCase());
                }

            }

        }
        else if(Objects.equals(source, "CE")){
            addBuffor();
            removeLast();
            textfield.setText(currentText);
        }
        else if(Objects.equals(source, "C")){
            currentText = "";
            bufforText = "";
            textfield.setText(currentText);
        }
        else if (Objects.equals(source, "+")) {
            addBuffor();
            if (!ifContains()){
                currentText += "+";
                textfield.setText(currentText);
            }
            else{
                JOptionPane.showMessageDialog(this, "Znak  operacji został już użyty", "Błąd", JOptionPane.ERROR_MESSAGE);
            }
        }
        else if (Objects.equals(source, "-")) {
            addBuffor();
            if (!ifContains()){
                currentText += "-";
                textfield.setText(currentText);
            }
            else{
                JOptionPane.showMessageDialog(this, "Znak  operacji został już użyty","Błąd", JOptionPane.ERROR_MESSAGE);
            }

        }
        else if (Objects.equals(source, "/")) {
            addBuffor();
            if (!ifContains()){
                currentText += "/";
                textfield.setText(currentText);
            }
            else{
                JOptionPane.showMessageDialog(this, "Znak  operacji został już użyty", "Błąd", JOptionPane.ERROR_MESSAGE);
            }

        }
        else if (Objects.equals(source, "=")) {
            addBuffor();
            if (!ifContains()){
                JOptionPane.showMessageDialog(this, "Nie podałeś znaku operacji","Błąd", JOptionPane.ERROR_MESSAGE);
            } else if (currentText.contains("=")) {
                JOptionPane.showMessageDialog(this, "Podałeś już znak równa się","Błąd", JOptionPane.ERROR_MESSAGE);
            } else{
                currentText = currentText + "=" + calculate();
                textfield.setText(currentText);
            }
        }

    }
    public boolean ifContains(){
        if(currentText.contains("+") || currentText.contains("-") || currentText.contains("/")){
            return true;
        }
        return false;
    }

    public String calculate(){
        if(currentText.contains("+")){
            return add();
        } else if (currentText.contains("-")) {
            return substract();
        } else if (currentText.contains("/")) {
            return divide();
        }
        return "";
    }
    public String add(){
        String before;
        String after;
        int index = currentText.indexOf("+");
        before = currentText.substring(0,index);
        after = currentText.substring(index + 1);
        return before + after;
    }
    public String substract(){
        String before;
        String after;
        int index = currentText.indexOf("-");
        before = currentText.substring(0, index);
        after = currentText.substring(index + 1);
        System.out.println(before);
        System.out.println(after);
        return before.replace(after, "");
    }

    public String divide(){
        String before;
        String after;
        int index = currentText.indexOf("/");
        before = currentText.substring(0, index);
        after = currentText.substring(index + 1);
        return commonSubstring(before, after);
    }

    private String commonSubstring(String str1, String str2) {
        int maxLength = 0;
        int endIndex = 0;
        int[][] dp = new int[str1.length() + 1][str2.length() + 1];

        for (int i = 1; i <= str1.length(); i++) {
            for (int j = 1; j <= str2.length(); j++) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                    if (dp[i][j] > maxLength) {
                        maxLength = dp[i][j];
                        endIndex = i;
                    }
                }
            }
        }

        return str1.substring(endIndex - maxLength, endIndex);
    }
    public static void removeLast(){
        if(!currentText.isEmpty()){
            currentText = currentText.substring(0, currentText.length()-1);
        }
    }
    public void addBuffor(){
        if(!bufforText.isEmpty()){
            currentText += bufforText;
        }
        bufforText = "";
    }

}
