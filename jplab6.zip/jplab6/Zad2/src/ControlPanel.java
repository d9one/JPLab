import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ControlPanel extends JPanel {
    List<Snail> snailList = new ArrayList<>();
    public ControlPanel(int w, int h, int n) {
        setPreferredSize(new Dimension(600 , 600));
        setLayout(new FlowLayout());
        Leaf leaf = new Leaf(w, h);
        for(int i=0; i<n; i++){
            Snail snail = new Snail(randomValue(w), randomValue(h), randomValue(10)+1, leaf, randomValue(1000)+200);
            snailList.add(snail);
        }
        leaf.setSnailList(snailList);

        PaintLeaf paintLeaf = new PaintLeaf(w, h, leaf);
        add(paintLeaf);
        paintLeaf.repaint();
        RefreshThread refreshThread = new RefreshThread(leaf);
        PaintThread paintThread = new PaintThread(paintLeaf);
        refreshThread.start();
        paintThread.start();
        for (Snail s: snailList) {
            s.start();
        }
    }

    public int randomValue(int x){
        Random random = new Random();
        return random.nextInt(x);
    }
}
