import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Leaf {
    int w;
    int h;
    int [][] cells;
    List<Snail> snailList;

    public Leaf(int w, int h){
        this.w = w;
        this.h = h;
        cells = new int[w][h];

        for(int i=0; i<w; i++){
            for(int j=0; j<h; j++){
                cells[i][j] = randomFood();
            }
        }
    }

    public int[][] getCells() {
        return cells;
    }

    public void setSnailList(List<Snail> snailList) {
        this.snailList = snailList;
    }

    public int randomFood(){
        Random random = new Random();
        return random.nextInt(11);
    }

    public synchronized void incFood() {
        for(int i=0; i<w; i++){
            for(int j=0; j<h; j++){
                if(cells[i][j] < 10){
                    cells[i][j] +=1;
                }
            }
        }
    }

    public synchronized void moveSnail(Snail snail){
        int max_x = snail.x;
        int max_y = snail.y;

        if (snail.x-1>=0 && cells[snail.x-1][snail.y] > cells[max_x][max_y]
        && !ifSnail(snail.x-1, snail.y)){
            max_x = snail.x-1;
            max_y = snail.y;
        }

        if (snail.x+1<w && cells[snail.x+1][snail.y] > cells[max_x][max_y]
                && !ifSnail(snail.x+1, snail.y)){
            max_x = snail.x+1;
            max_y = snail.y;
        }

        if (snail.y-1>=0 && cells[snail.x][snail.y-1] > cells[max_x][max_y]
                && !ifSnail(snail.x, snail.y-1)){
            max_x = snail.x;
            max_y = snail.y-1;
        }

        if (snail.y+1<h && cells[snail.x][snail.y+1] > cells[max_x][max_y]
                && !ifSnail(snail.x, snail.y+1)){
            max_x = snail.x;
            max_y = snail.y+1;
        }

        if (snail.x-1>=0 && snail.y-1>=0 && cells[snail.x-1][snail.y-1] > cells[max_x][max_y]
                && !ifSnail(snail.x-1, snail.y-1)){
            max_x = snail.x-1;
            max_y = snail.y-1;
        }

        if (snail.x-1>=0 && snail.y+1<h && cells[snail.x-1][snail.y+1] > cells[max_x][max_y]
                && !ifSnail(snail.x-1, snail.y+1)){
            max_x = snail.x-1;
            max_y = snail.y+1;
        }

        if (snail.x+1<w && snail.y+1<h && cells[snail.x+1][snail.y+1] > cells[max_x][max_y]
                && !ifSnail(snail.x+1, snail.y+1)){
            max_x = snail.x+1;
            max_y = snail.y+1;
        }

        if (snail.x+1<w && snail.y-1>=0 && cells[snail.x+1][snail.y-1] > cells[max_x][max_y]
                && !ifSnail(snail.x+1, snail.y-1)){
            max_x = snail.x+1;
            max_y = snail.y-1;
        }
        snail.x = max_x;
        snail.y = max_y;

        if(snail.speed <= cells[snail.x][snail.y]){
            cells[snail.x][snail.y] -= snail.speed;
        } else {
            cells[snail.x][snail.y] = 0;
        }

    }

    public boolean ifSnail(int x, int y){
        for (Snail s: snailList) {
            if(s.x==x && s.y==y){
                return true;
            }
        }
        return false;
    }
}
