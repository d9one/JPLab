import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class PaintLeaf extends JPanel {
    int w;
    int h;
    Leaf leaf;

    public PaintLeaf(int w, int h, Leaf leaf){
        this.w = w;
        this.h = h;
        this.leaf = leaf;
        setPreferredSize(new Dimension(600, 600));
    }

    @Override
    public void paintComponent(Graphics g){
        Graphics2D g2d = (Graphics2D) g;

        int rectSize = Math.min(getWidth() / w, getHeight()/ h);

        for(int i=0; i<w; i++){
            for(int j=0; j<h; j++){
                Color color = getColor(leaf.getCells()[i][j]);
                g2d.setColor(color);
                g2d.fillRect(i * rectSize, j * rectSize, rectSize,rectSize);
            }
        }
        for (Snail s: leaf.snailList) {
            Ellipse2D.Double circle = new Ellipse2D.Double(s.x * rectSize, s.y * rectSize, rectSize / 2, rectSize / 2);
            g2d.setColor(Color.red);
            g2d.fill(circle);
        }
    }

    public Color getColor(int x) {
        if(x==0){
            return new Color(255, 255 ,255);
        }
        else{
            int red = 0;
            int green = 255 - (x * 20);
            int blue = 0;

            return new Color(red, green, blue);
        }
    }

}
