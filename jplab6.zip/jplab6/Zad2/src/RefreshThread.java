public class RefreshThread extends Thread{
    Leaf leaf;
    public RefreshThread(Leaf leaf){
        this.leaf = leaf;
    }

    @Override
    public void run(){
        while(true){
            leaf.incFood();
            try {
                this.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

}
