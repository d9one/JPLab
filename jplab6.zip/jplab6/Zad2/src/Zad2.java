import javax.swing.*;

public class Zad2 extends JFrame {
    public Zad2(int w, int h, int n){
        super("Zadanie2");
        ControlPanel controlPanel = new ControlPanel(w, h, n);
        add(controlPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setResizable(false);
        setVisible(true);
    }
    public static void main(String[] args) {
        int w = Integer.parseInt(args[0]);
        int h = Integer.parseInt(args[1]);
        int n = Integer.parseInt(args[2]);
        if(args.length!=3){
            throw new IndexOutOfBoundsException("Podaj 3 argumenty typu int (w, h, n)");
        }
        SwingUtilities.invokeLater(()->new Zad2(w, h, n));
    }
}