public class PaintThread extends Thread{
    PaintLeaf paint;

    public PaintThread(PaintLeaf paint){
        this.paint = paint;
    }


    @Override
    public void run(){
        while(true){
            paint.repaint();
            try {
                this.sleep(10);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

}