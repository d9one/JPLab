public class Snail extends Thread{
    int x;
    int y;
    int speed;
    Leaf leaf;
    int sleepTime;


    public Snail(int x, int y, int speed, Leaf leaf, int sleepTime){
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.leaf = leaf;
        this.sleepTime = sleepTime;
    }

    @Override
    public void run() {
        while(true){
            leaf.moveSnail(this);
            try {
                this.sleep(sleepTime);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
