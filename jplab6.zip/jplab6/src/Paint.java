import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.List;

public class Paint extends JPanel{
    final int SMALLRADIUS = 10;
    List<Circle> circleList;

    public Paint(List<Circle> circleList){
        this.circleList = circleList;
        setPreferredSize(new Dimension(400, 400));
    }

    @Override
    public void paintComponent(Graphics g){
        g.clearRect(0, 0, getWidth(), getHeight());
        Graphics2D g2d = (Graphics2D) g;

        int diameter = Math.min(getWidth(), getHeight());
        int x = (getWidth() - diameter) / 2;
        int y = (getHeight() - diameter) / 2;

        Ellipse2D.Double circle = new Ellipse2D.Double(x, y, diameter, diameter);

        g2d.setColor(Color.GRAY);
        g2d.fill(circle);

        for (Circle i : circleList) {
            Ellipse2D.Double smallCircle = new Ellipse2D.Double(i.calculateX()+200-SMALLRADIUS, i.calculateY()+200-SMALLRADIUS, SMALLRADIUS*2, SMALLRADIUS*2);
            g2d.setColor(i.color);
            g2d.fill(smallCircle);
        }
    }

}
