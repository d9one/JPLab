import java.awt.*;

public class Circle {
    int speed;
    Color color;
    int radius;
    double angle;

    public Circle(int speed, Color color, int radius, double angle){
        this.speed = speed;
        this.color = color;
        this.radius = radius;
        this.angle = angle;
    }

    public double calculateX(){
        return radius * Math.cos(angle);
    }

    public double calculateY(){
        return radius * Math.sin(angle);
    }
}
