import javax.swing.*;

public class ManagerCircle extends Thread {
    Circle circle;
    Circle circleNext;
    JSlider jSlider;

    public ManagerCircle(JSlider jSlider, Circle circle){
        this.jSlider = jSlider;
        this.circle = circle;
    }

    public void setCircleNext(Circle circleNext) {
        this.circleNext = circleNext;
    }

    @Override
    public void run(){
        while(true){
            AngleComparator.compareAngles(circle, circleNext, jSlider.getValue());
            try {
                this.sleep(10);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }


}
