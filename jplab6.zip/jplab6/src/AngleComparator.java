public class AngleComparator {
    public static synchronized void compareAngles(Circle circle, Circle circleNext, int sliderValue){
        if (circle.angle < circleNext.angle) {
            circle.angle += ((double) sliderValue) / 2000D;

            if (circleNext.angle - 0.1 < circle.angle){
                circle.angle = (circleNext.angle - 0.1);
            }
        } else {
            circle.angle += ((double) sliderValue) / 2000D;

            if (circleNext.angle + 2*Math.PI - 0.1 < circle.angle){
                circle.angle = (circleNext.angle - 0.1);
            }
        }

    }
}
