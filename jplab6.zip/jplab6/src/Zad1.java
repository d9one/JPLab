import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class Zad1 extends JFrame {
    public Zad1(int n) {
        super("Zadanie1");
        List<Circle> listOfCircles = new ArrayList<>();
        List<JSlider> jSliderList;
        List<ManagerCircle> managerList = new ArrayList<>();

        for(int i=0; i<n; i++){
            Random random = new Random();
            int speed = random.nextInt(100);

            listOfCircles.add(createCircle(400, generateColor(), speed));
        }

        Collections.sort(listOfCircles, Comparator.comparingDouble(circle -> circle.angle));


        jSliderList = listOfCircles.stream().map(c -> {
            JSlider jSlider = new JSlider();
            jSlider.setValue(c.speed);
            return  jSlider;
        }).toList();


        for(int i=0; i<n-1; i++){
            ManagerCircle managerCircle = new ManagerCircle(jSliderList.get(i), listOfCircles.get(i));
            managerList.add(managerCircle);
            managerCircle.setCircleNext(listOfCircles.get(i+1));
            managerCircle.start();
        }

        ManagerCircle managerCircle = new ManagerCircle(jSliderList.get(n-1), listOfCircles.get(n-1));
        managerCircle.setCircleNext(listOfCircles.get(0));
        managerCircle.start();

        Paint paintPanel = new Paint(listOfCircles);
        PaintThread paintThread = new PaintThread(paintPanel);
        paintThread.start();

        ControlPanel controlPanel = new ControlPanel(paintPanel, listOfCircles, jSliderList, n);
        add(controlPanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setResizable(false);
        setVisible(true);
    }
    public Circle createCircle(int diameter, Color color, int speed){
        int radius = diameter / 2;
        Random random = new Random();
        float angle = random.nextFloat(6);
        Circle circle = new Circle(speed, color, radius, angle);

        return  circle;
    }
    public Color generateColor(){
        Random random = new Random();
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        return new Color(red, blue, green);
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        if(args.length!=1){
            throw new IndexOutOfBoundsException("Podaj 1 argument");
        }

        SwingUtilities.invokeLater(()-> new Zad1(n));
    }
}
