import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ControlPanel extends JPanel {
    Paint paintPanel;
    List<Circle> listOfCircles;

    public ControlPanel(Paint paintPanel, List<Circle> listOfCircles, List<JSlider> jSliderList, int n){
        this.paintPanel = paintPanel;
        this.listOfCircles = listOfCircles;
        setPreferredSize(new Dimension(600 , 400));
        JPanel control = new JPanel();
        control.setLayout(new GridLayout(n, 1));
        for(JSlider x: jSliderList){
            control.add(x);
        }
        setLayout(new BorderLayout());
        add(paintPanel, BorderLayout.WEST);
        add(control, BorderLayout.EAST);
    }

}
