public class PaintThread extends Thread{
    Paint paint;

    public PaintThread(Paint paint){
        this.paint = paint;
    }


    @Override
    public void run(){
        while(true){
            paint.repaint();
            try {
                this.sleep(10);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

}
