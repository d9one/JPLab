import java.util.ArrayList;
import java.util.Random;
public class Samochod {
    public enum Marka{
        POLONEZ,
        FIAT,
        SYRENA,
    }
    private Marka marka;
    private int cena;
    private int rocznik;

    public Samochod(Marka marka, int cena, int rocznik){
        this.marka=marka;
        this.cena=cena;
        this.rocznik=rocznik;
    }

    public Marka getMarka() {
        return marka;
    }

    public int getCena() {
        return cena;
    }

    public int getRocznik() {
        return rocznik;
    }

    public static Marka losujMarke(){
        Random random = new Random();
        Marka[] marki = Marka.values();
        int indeks;
        indeks = random.nextInt(marki.length);
        Marka marka = marki[indeks];
        return marka;
    }
    public static int losujCene(){
        Random random = new Random();
        int cena = random.nextInt(99001) + 1000;
        return cena;
    }
    public static int losujRocznik(){
        Random random = new Random();
        int rocznik = random.nextInt(74) + 1950;
        return rocznik;
    }
    public static ArrayList<Samochod> utworzSamochody(int n){
        ArrayList<Samochod> samochody = new ArrayList<>();
        for(int i=0; i<n; i++){
            samochody.add(i, new Samochod(losujMarke(), losujCene(), losujRocznik()));
        }
        return samochody;
    }

    @Override
    public String toString() {
        return "Marka: " + marka + ", Cena: " + cena + ", Rok: " + rocznik;
    }
}