import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws Wyjatek {
        try {
            if (args.length == 0) {
                throw new IndexOutOfBoundsException("Nie podales parametrow");
            } else if (args.length != 2) {
                throw new IllegalArgumentException("Podaj 2 parametry");
            } else if (!(args[1].equals("W") || args[1].equals("R"))) {
                throw new IllegalArgumentException("Podales jako 2 parametr coś innego niz \"W\", \"R\"");
            }
            else {
                int n = 0;
                try {
                    n = Integer.parseInt(args[0]);
                    if (n <= 0) {
                        throw new IllegalArgumentException("Pierwszy argyment musi byc dodatni");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Pierwszy argument musi być liczbą typu int");
                    System.exit(1);
                }
                ArrayList<Samochod> samochody = Samochod.utworzSamochody(n);
                for (Samochod samochod : samochody) {
                    System.out.println(samochod.toString());
                }
                ArrayList<Samochod> znalezioneSamochody = new ArrayList<>();
                System.out.println("Kryteria szukania samochodów:");
                System.out.println("1. najstarszy,\n2. nie starszy niż ROK,\n3. najmlodszy,\n4. nie mlodszy niż ROK");
                switch (Kryteria.Kryterium()) {
                    case 1:
                        znalezioneSamochody = Kryteria.najstarszy(samochody);
                        break;
                    case 2:
                        znalezioneSamochody = Kryteria.nieStarszyNiz(samochody);
                        break;
                    case 3:
                        znalezioneSamochody = Kryteria.najmlodszy(samochody);
                        break;
                    case 4:
                        znalezioneSamochody = Kryteria.nieMlodszyNiz(samochody);
                        break;
                    default:
                        System.out.println("Podałeś inną cyfrę niż 1, 2, 3, 4");
                }

                if (args[1].equals("W")) {
                    throw new Wyjatek(znalezioneSamochody);
                } else if (args[1].equals("R")) {
                    System.out.println(znalezioneSamochody);
                }
            }
        } catch (IndexOutOfBoundsException | IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}

