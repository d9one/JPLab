import java.util.ArrayList;

public class Kryteria {
    public static int Kryterium(){
        EasyReader stdin = new EasyReader(System.in);
        return stdin.intQuery("Podal liczbe typu int od 1-4: ");
    }
    public static int Rocznik(){
        EasyReader stdin = new EasyReader(System.in);
        return stdin.intQuery("Podaj rocznik: ");
    }
    public static ArrayList<Samochod> najstarszy(ArrayList<Samochod> samochody){
        int indexMax;
        indexMax = 0;
        ArrayList<Samochod> najstarsze  = new ArrayList<>();
        for (Samochod samochod:samochody) {
            if(samochod.getRocznik() < samochody.get(indexMax).getRocznik()){
                indexMax = samochody.indexOf(samochod);
            }
        }
        for (Samochod samochod:samochody) {
            if(samochod.getRocznik() == samochody.get(indexMax).getRocznik()){
                najstarsze.add(samochod);
            }
        }

        return najstarsze;
    }
    public static ArrayList<Samochod> najmlodszy(ArrayList<Samochod> samochody){
        int indexMin;
        indexMin = 0;
        ArrayList<Samochod> najmlodzsze  = new ArrayList<>();
        for (Samochod samochod:samochody) {
            if(samochod.getRocznik() > samochody.get(indexMin).getRocznik()){
                indexMin = samochody.indexOf(samochod);
            }
        }
        for (Samochod samochod:samochody) {
            if(samochod.getRocznik() == samochody.get(indexMin).getRocznik()){
                najmlodzsze.add(samochod);
            }
        }

        return najmlodzsze;
    }
    public static ArrayList<Samochod> nieStarszyNiz( ArrayList<Samochod> samochody){
        int rocznik = Rocznik();
        ArrayList<Samochod> niestarszeniz = new ArrayList<>();
        for (Samochod samochod: samochody) {
            if(samochod.getRocznik()>=rocznik){
                niestarszeniz.add(samochod);
            }
        }
        return niestarszeniz;
    }
    public static ArrayList<Samochod> nieMlodszyNiz( ArrayList<Samochod> samochody){
        int rocznik = Rocznik();
        ArrayList<Samochod> niemlodszeniz = new ArrayList<>();
        for (Samochod samochod: samochody) {
            if(samochod.getRocznik()<=rocznik){
                niemlodszeniz.add(samochod);
            }
        }
        return niemlodszeniz;
    }
}
