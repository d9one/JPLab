import java.util.ArrayList;

public class Wyjatek extends Exception{
    public Wyjatek(ArrayList<Samochod> samochody){
        super(String.valueOf(samochody));
    }
}
